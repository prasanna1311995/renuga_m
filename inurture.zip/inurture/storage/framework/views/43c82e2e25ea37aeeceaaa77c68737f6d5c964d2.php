<div class="form-group <?php echo e($errors->has('course_id') ? 'has-error' : ''); ?>">
    <label for="course_id" class="control-label"><?php echo e('Course Id'); ?></label>
    <input class="form-control" name="course_id" type="text" id="course_id" value="<?php echo e(isset($course->course_id) ? $course->course_id : ''); ?>" >
    <?php echo $errors->first('course_id', '<p class="help-block">:message</p>'); ?>

</div>
<div class="form-group <?php echo e($errors->has('course_name') ? 'has-error' : ''); ?>">
    <label for="course_name" class="control-label"><?php echo e('Course Name'); ?></label>
    <input class="form-control" name="course_name" type="text" id="course_name" value="<?php echo e(isset($course->course_name) ? $course->course_name : ''); ?>" >
    <?php echo $errors->first('course_name', '<p class="help-block">:message</p>'); ?>

</div>
<div class="form-group <?php echo e($errors->has('course_type') ? 'has-error' : ''); ?>">
    <label for="course_type" class="control-label"><?php echo e('Course Type'); ?></label>
    <input class="form-control" name="course_type" type="text" id="course_type" value="<?php echo e(isset($course->course_type) ? $course->course_type : ''); ?>" >
    <?php echo $errors->first('course_type', '<p class="help-block">:message</p>'); ?>

</div>


<div class="form-group">
    <input class="btn btn-primary" type="submit" value="<?php echo e($formMode === 'edit' ? 'Update' : 'Create'); ?>">
</div>
